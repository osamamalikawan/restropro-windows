//! Lets the bundled screens keep calling `fetch("/api/...")`: the web layer hands each request to
//! `api_request`, which forwards it to the cloud server with this device's credentials and the
//! id of the cashier signed in on the device (PIN checked locally). Server-side, each request is
//! re-authorised from the database (employee active + role + same restaurant + device not revoked).
//! Offline, the call simply fails and the screen shows its normal network-error state.

use crate::staff_auth::SessionState;
use crate::sync::API_BASE;
use serde::Serialize;
use std::time::Duration;
use tauri::{AppHandle, Manager};

/// Never reachable through the bridge, whatever the screen asks for.
const BLOCKED_PREFIXES: [&str; 4] = ["/api/device/", "/api/super-admin", "/api/cron", "/api/staff/login"];

#[derive(Serialize)]
pub struct ApiReply {
    status: u16,
    content_type: Option<String>,
    body: String,
}

fn check_path(path: &str) -> Result<(), String> {
    if !path.starts_with("/api/") || path.contains("..") || path.contains('\\') || path.contains("//") {
        return Err("Blocked request path".to_string());
    }
    let lower = path.to_lowercase();
    if BLOCKED_PREFIXES.iter().any(|p| lower.starts_with(p)) {
        return Err("This request is not available from the desktop app".to_string());
    }
    Ok(())
}

#[tauri::command]
pub async fn api_request(
    app: AppHandle,
    method: String,
    path: String,
    body: Option<String>,
    content_type: Option<String>,
) -> Result<ApiReply, String> {
    check_path(&path)?;
    let method = reqwest::Method::from_bytes(method.to_uppercase().as_bytes()).map_err(|_| "Bad method".to_string())?;
    if ![reqwest::Method::GET, reqwest::Method::POST, reqwest::Method::PUT, reqwest::Method::PATCH, reqwest::Method::DELETE].contains(&method) {
        return Err("Method not allowed".to_string());
    }

    tauri::async_runtime::spawn_blocking(move || -> Result<ApiReply, String> {
        let token = crate::secure_store::secure_get("device_token".to_string())?
            .ok_or_else(|| "This device is not activated yet".to_string())?;
        let employee_id = app
            .state::<SessionState>()
            .0
            .lock()
            .map_err(|e| e.to_string())?
            .as_ref()
            .map(|s| s.employee_id.clone())
            .ok_or_else(|| "Not signed in".to_string())?;

        let client = reqwest::blocking::Client::builder()
            .timeout(Duration::from_secs(30))
            .build()
            .map_err(|e| e.to_string())?;

        let mut req = client
            .request(method, format!("{API_BASE}{path}"))
            .bearer_auth(token)
            .header("x-staff-id", employee_id);
        if let Some(b) = body {
            req = req.header("content-type", content_type.unwrap_or_else(|| "application/json".to_string())).body(b);
        }

        let resp = req.send().map_err(|e| format!("Could not reach the server — {e}"))?;
        let status = resp.status().as_u16();
        let content_type = resp
            .headers()
            .get("content-type")
            .and_then(|v| v.to_str().ok())
            .map(|s| s.to_string());
        let body = resp.text().map_err(|e| format!("Could not read the server response — {e}"))?;
        Ok(ApiReply { status, content_type, body })
    })
    .await
    .map_err(|e| e.to_string())?
}