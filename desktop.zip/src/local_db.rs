use rusqlite::{params, Connection};
use std::sync::Mutex;

pub struct Db(pub Mutex<Connection>);

fn db_path() -> std::path::PathBuf {
    dirs::data_dir().unwrap().join("restropro").join("local.db")
}

pub fn init() -> Db {
    let path = db_path();
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).ok();
    }
    let conn = Connection::open(&path).expect("failed to open local database");
    conn.execute_batch(
        "
        CREATE TABLE IF NOT EXISTS device_info (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            restaurant_id TEXT NOT NULL,
            restaurant_name TEXT NOT NULL,
            slug TEXT NOT NULL,
            last_synced_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS staff_cache (
            employee_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            role TEXT NOT NULL,
            pin_hash TEXT NOT NULL,
            status TEXT NOT NULL
        );
        -- Last server snapshot, one JSON document per kind (products, tables, areas,
        -- payment_methods, settings, customers). Replaced wholesale on every sync.
        CREATE TABLE IF NOT EXISTS cache (
            kind TEXT PRIMARY KEY,
            json TEXT NOT NULL
        );
        -- Sales rung up on this device. 'pending' -> uploaded -> 'synced', or 'rejected' when
        -- the server refused it (reason in `error`; kept so nothing is silently lost).
        CREATE TABLE IF NOT EXISTS sales_outbox (
            seq INTEGER PRIMARY KEY AUTOINCREMENT,
            client_sale_id TEXT NOT NULL UNIQUE,
            payload TEXT NOT NULL,
            created_at TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            order_no TEXT,
            error TEXT
        );
        CREATE TABLE IF NOT EXISTS sync_state (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            last_sync_at TEXT,
            max_clock_seen TEXT,
            last_error TEXT,
            revoked INTEGER NOT NULL DEFAULT 0
        );
        INSERT OR IGNORE INTO sync_state (id) VALUES (1);
        ",
    )
    .expect("failed to initialize local database schema");
    Db(Mutex::new(conn))
}

#[derive(serde::Deserialize)]
pub struct StaffCacheRow {
    pub id: String,
    pub name: String,
    pub role: String,
    pub pin_hash: String,
    pub status: String,
}

pub fn store_device_and_roster(
    db: &Db,
    restaurant_id: &str,
    restaurant_name: &str,
    slug: &str,
    roster: &[StaffCacheRow],
) -> Result<(), String> {
    let mut conn = db.0.lock().map_err(|e| e.to_string())?;
    let tx = conn.transaction().map_err(|e| e.to_string())?;

    let now = chrono::Utc::now().to_rfc3339();
    tx.execute(
        "INSERT INTO device_info (id, restaurant_id, restaurant_name, slug, last_synced_at)
         VALUES (1, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET restaurant_id=excluded.restaurant_id,
            restaurant_name=excluded.restaurant_name, slug=excluded.slug, last_synced_at=excluded.last_synced_at",
        params![restaurant_id, restaurant_name, slug, now],
    )
    .map_err(|e| e.to_string())?;

    tx.execute(
        "UPDATE sync_state SET last_sync_at = ?1, max_clock_seen = ?1, last_error = NULL, revoked = 0 WHERE id = 1",
        params![now],
    )
    .map_err(|e| e.to_string())?;

    tx.execute("DELETE FROM staff_cache", []).map_err(|e| e.to_string())?;
    for row in roster {
        tx.execute(
            "INSERT INTO staff_cache (employee_id, name, role, pin_hash, status) VALUES (?, ?, ?, ?, ?)",
            params![row.id, row.name, row.role, row.pin_hash, row.status],
        )
        .map_err(|e| e.to_string())?;
    }

    tx.commit().map_err(|e| e.to_string())
}

/// Replace the local copy of the server data with a fresh /api/device/sync response.
/// One transaction: either the whole snapshot lands or none of it does.
pub fn apply_snapshot(db: &Db, snap: &serde_json::Value) -> Result<(), String> {
    let roster: Vec<StaffCacheRow> = serde_json::from_value(snap["staffRoster"].clone())
        .map_err(|e| format!("Bad staff roster in sync response — {e}"))?;

    let mut conn = db.0.lock().map_err(|e| e.to_string())?;
    let tx = conn.transaction().map_err(|e| e.to_string())?;

    let kinds: [(&str, &serde_json::Value); 8] = [
        ("products", &snap["products"]),
        ("tables", &snap["tables"]),
        ("areas", &snap["areas"]),
        ("payment_methods", &snap["paymentMethods"]),
        ("customers", &snap["customers"]),
        // role -> module -> can_view, and subscription status: lets the sidebar, page guards and
        // top bar behave like the web app while offline.
        ("permissions", &snap["permissionMatrix"]),
        ("meta", &serde_json::json!({ "subStatus": snap["subStatus"] })),
        (
            "settings",
            &serde_json::json!({ "restaurant": snap["restaurant"], "settings": snap["settings"] }),
        ),
    ];
    for (kind, value) in kinds {
        tx.execute(
            "INSERT INTO cache (kind, json) VALUES (?1, ?2) ON CONFLICT(kind) DO UPDATE SET json = excluded.json",
            params![kind, value.to_string()],
        )
        .map_err(|e| e.to_string())?;
    }

    tx.execute("DELETE FROM staff_cache", []).map_err(|e| e.to_string())?;
    for row in &roster {
        tx.execute(
            "INSERT INTO staff_cache (employee_id, name, role, pin_hash, status) VALUES (?, ?, ?, ?, ?)",
            params![row.id, row.name, row.role, row.pin_hash, row.status],
        )
        .map_err(|e| e.to_string())?;
    }

    if let Some(name) = snap["restaurant"]["name"].as_str() {
        tx.execute("UPDATE device_info SET restaurant_name = ? WHERE id = 1", params![name])
            .map_err(|e| e.to_string())?;
    }

    let now = chrono::Utc::now().to_rfc3339();
    tx.execute(
        "UPDATE sync_state SET last_sync_at = ?1, max_clock_seen = ?1, last_error = NULL, revoked = 0 WHERE id = 1",
        params![now],
    )
    .map_err(|e| e.to_string())?;
    tx.execute("UPDATE device_info SET last_synced_at = ? WHERE id = 1", params![now])
        .map_err(|e| e.to_string())?;

    tx.commit().map_err(|e| e.to_string())
}
